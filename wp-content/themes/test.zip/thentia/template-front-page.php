<?php get_header();
/*
template name: front page
*/?>

<?php the_content(); ?>

<?php get_footer(); ?>