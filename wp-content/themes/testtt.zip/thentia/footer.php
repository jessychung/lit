<?php wp_footer(); ?>

</body>

<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">

            </div>
            <div class="col-md-6" style="text-align: right">
                <p>© <?php echo date("Y"); ?> Thentia Corporation. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

</html>